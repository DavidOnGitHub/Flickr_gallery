import React from 'react';

import styles from 'Dashboard/Dashboard.css';

export default class CustomerTable extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      sortBys: []
    }

    this.getHeaders = this.getHeaders.bind(this);
    this.getRows = this.getRows.bind(this);
    this.setSortBys = this.setSortBys.bind(this);
    this.sort = this.sort.bind(this);
  }

  setSortBys(event, header) {
    const { sortBys } = this.state;
    const currentSortByIndex = sortBys.findIndex(sortBy => sortBy.header === header);

    let newSortBys;
    if (currentSortByIndex < 0) {
      newSortBys = (event.ctrlKey || event.metaKey) ? [...sortBys, { header, order: 1 }] : [{ header, order: 1 }];
    } else if (sortBys[currentSortByIndex].order > 0) {
      if (event.ctrlKey || event.metaKey) {
        newSortBys = [...sortBys];
        newSortBys.splice(currentSortByIndex, 1, { header, order: -1 });
      } else {
        newSortBys = [{ header, order: -1 }];
      }
    } else {
      newSortBys = [...sortBys];
      newSortBys.splice(currentSortByIndex, 1);
    }

    this.setState({ sortBys: newSortBys });
  }

  sort(data) {
    const sortBys = [...this.state.sortBys];

    return [...data].sort((customer1, customer2) => {
      for (let sortBy of sortBys) {
        if (customer1[sortBy.header] < customer2[sortBy.header]) {
          return -sortBy.order;
        }

        if (customer1[sortBy.header] > customer2[sortBy.header]) {
          return sortBy.order;
        }
      }

      return 0;
    });
  }

  getIndicatorClass(order) {
    if (order > 0) {
      return styles.ascending;
    } else if (order < 0) {
      return styles.descending;
    }

    return '';
  }

  getHeaders() {
    const { data } = this.props;
    const { sortBys } = this.state;
    const headers = Object.keys(data[0]);
    const shouldShowOrder = sortBys.length > 1;

    return (
    <tr>
      {headers.map(header => {
        const currentSortBy = sortBys.find(sortBy => sortBy.header === header);
        return (
          <th key={header}>
            <div className={styles.header} onClick={(event) => this.setSortBys(event, header)}>
            {header}
            <span className={`${styles.indicator} ${currentSortBy ? this.getIndicatorClass(currentSortBy.order) : ''}`}>
              <div className={styles.up}/>
              <div className={styles.down}/>
            </span>
            { shouldShowOrder && currentSortBy &&
            <span className={styles.order}>{sortBys.indexOf(currentSortBy) + 1}</span>
            }
            </div>
          </th>
        );
      })}
    </tr>
    );
  }

  getRows() {
    const { data } = this.props;
    const sortedData = this.sort(data);

    return sortedData.map((customer, trIndex) => (
    <tr key={trIndex}>
    {Object.values(customer).map((value, tdIndex) => <td key={tdIndex}>{value}</td>)}
    </tr>
    ));
  }

  render() {

    return this.props.data && this.props.data.length > 0 ? (
      <table className={styles.table}>
        <thead>{this.getHeaders()}</thead>
        <tbody>{this.getRows()}</tbody>
      </table>
      ) : null;
  }
}
