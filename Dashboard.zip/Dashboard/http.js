const mockTableData = [
  { id: 5, name: 'abraham', family: 'blue', city: 'darwin', score: 500 },
  { id: 1, name: 'jack', family: 'hanson', city: 'sydney', score: 100 },
  { id: 6, name: 'pieter', family: 'smith', city: 'sydney', score: 400 },
  { id: 3, name: 'joe', family: 'larson', city: 'brisbane', score: 300 },
  { id: 2, name: 'pieter', family: 'street', city: 'melbourne', score: 200 },
  { id: 4, name: 'simon', family: 'long', city: 'perth', score: 400 },
  { id: 7, name: 'pieter', family: 'street', city: 'melbourne', score: 100 }
];

export const getTableData = () => Promise.resolve(mockTableData);
